//RTC.c
#include<lpc21xx.h>
#include<stdio.h>
#include "types.h"
#include "lcd_defines.h"
#include "lcd.h"
#include "RTC.h"
#include "KPM.h"
void InitRTC(void)
{		 
	CCR=0x02;//Reset RTC
	//CCR|=(1<<4);
	//PREINT=0x1C8;
	//PREFRAC=0x61C0;
	/*SEC=30;
	MIN=22;
	HOUR=6;
	DOM=16;
	MONTH=10;
	YEAR=2026;*/
	CCR=0x11;//Start RTC
}
void Set_RTC_Time()
{
	u32 hour,min,sec;
	CmdLCD(0x01);
chg:StrLCD("set Hour");
    hour=set_time();
	CmdLCD(0x01);
	StrLCD("set min");
	min=set_time();
	CmdLCD(0x01);
	StrLCD("set sec");
	sec=set_time();
	if(hour>23 ||min>59||sec>59)
	{
	  CmdLCD(0x01);
	  goto chg;
	}
	HOUR=hour;
	MIN=min;
	SEC=sec;
}
void Set_RTC_Date()
{
	u32 date,month,year;
	CmdLCD(0x01);
chg:StrLCD("Set Date");
	date=set_time();
	CmdLCD(0x01);
	StrLCD("Set Month");
	month=set_time();
	CmdLCD(0x01);
	StrLCD("Set Year");
	year=set_time();
	if(date<1 || date>31 || month<1||month>12)
	{
	  CmdLCD(0x01);
	  goto chg;
	}
	DOM=date;
	MONTH=month;
	YEAR=year;
}
void RTC_Read(s32 *s,s32 *m,s32 *h,s32 *d,s32 *M,s32 *y)
{
	*s=SEC;
	*m=MIN;
	*h=HOUR;
	*d=DOM;
	*M=MONTH;
	*y=YEAR;
}
void Display_RTC(void)
{
	s32 sec,min,hour;
	s32 day,month,year;
    char line[17];
	CmdLCD(0x01);
	RTC_Read(&sec,&min,&hour,&day,&month,&year);
	CmdLCD(GOTO_LINE1_POS0);
	sprintf(line,"DATE:%02u/%02u/%04u",day,month,year);
	StrLCD(line);
	CmdLCD(GOTO_LINE2_POS0);
	sprintf(line,"TIME:%02u:%02u:%02u",hour,min,sec);
	StrLCD(line);
}