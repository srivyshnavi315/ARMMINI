//RTC.h
void InitRTC(void);
void RTC_Read(s32 *s,s32 *m,s32 *h,s32 *d,s32 *M,s32 *y);
void Display_RTC(void);
void Set_RTC_Time(void);
void Set_RTC_Date(void);