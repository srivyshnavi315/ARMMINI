//main.c
#include "lcd.h"
#include "kpm.h"
#include "uart.h"
#include "rtc.h"
#include "atm_run.h"
#include "interrupt.h"
int main()
{
	InitKPM();
	InitLCD();
	InitRTC();
	Init_EINT1();
	UART0_Init();
	CmdLCD(0x01);
	atm_run();
}