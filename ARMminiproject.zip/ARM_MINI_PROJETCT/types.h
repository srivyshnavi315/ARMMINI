//types.h
typedef unsigned int u32;
typedef unsigned short int u16;
typedef unsigned char u8;
typedef  float f32;
typedef signed int s32;
typedef signed char s8;
