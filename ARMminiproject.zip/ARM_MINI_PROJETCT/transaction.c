#include "lcd.h"
#include "lcd_defines.h"
#include "kpm.h"
#include "types.h"
#include "transaction.h"
#include "transaction_history.h"
#include "delay.h"
#include "rtc.h"
#include "uart.h"
#include<lpc21xx.h>
#include<stdio.h>

#define BUZZER 1

u32 Bal,amnt;;
s32 sec,min,hour;
s32 day,month,year;
char log[200];

void Balance(u32 acc_no)
{
	
	
	CmdLCD(0x01);
	CmdLCD(GOTO_LINE1_POS0);
    StrLCD("Available Bal..");
	CmdLCD(GOTO_LINE2_POS0);
    U32LCD(Bal);
	delay_s(3);
	CmdLCD(0x01);
	RTC_Read(&sec,&min,&hour,&day,&month,&year);
	sprintf(log,"[%02u-%02u-%04u/%02u:%02u:%02u] ACC:%u :BALANCE Rs.%u/-\r\n",day,month,year,hour,min,sec,acc_no,Bal);
	U0_TxStr(log);
}
void Withdraw(u32 acc_no)
{	
	CmdLCD(0x01);
	IODIR0|=1<<BUZZER;
	IOCLR0=1<<BUZZER;
	StrLCD("Avbl 100 200 500");
	delay_s(3);
	CmdLCD(0x01);
	CmdLCD(GOTO_LINE1_POS0);
	StrLCD("Enter Amnt");
	amnt=transaction_amnt();
	while(ColScan()==0);
	if(amnt<=Bal)
	{
	    //u8 log[200];
		Bal-=amnt;
		CmdLCD(0x01);
		CmdLCD(GOTO_LINE1_POS0);
		StrLCD("Withdraw success");
		delay_s(3);
		Add_History(acc_no,"WITHDRAW",amnt);
	    CmdLCD(0x01);
		RTC_Read(&sec,&min,&hour,&day,&month,&year);
		sprintf(log,"[%02u-%02u-%04u/%02u:%02u:%02u] ACC:%u :WITHDRAW: Rs.%u BALANCE: Rs.%u\r\n",day,month,year,hour,min,sec,acc_no,amnt,Bal);
		U0_TxStr(log);

	}
	else
	{
		CmdLCD(0x01);
	    CmdLCD(GOTO_LINE1_POS0);
		StrLCD("Insufficient Bal..");
		IOSET0=1<<BUZZER;
		delay_ms(500);
		IOCLR0=1<<BUZZER;
		delay_ms(500);
		delay_s(2);
		CmdLCD(0x01);

		
	}
}


void Deposit(u32 acc_no)
{
	CmdLCD(0x01);
	StrLCD("Avbl 100 200 500");
	delay_s(3);
	CmdLCD(0x01);
	CmdLCD(GOTO_LINE1_POS0);
	StrLCD("Enter Amnt");
	amnt=transaction_amnt();
	while(ColScan()==0);
	Bal+=amnt;
	CmdLCD(0x01);
	CmdLCD(GOTO_LINE1_POS0);
	StrLCD("Deposit success");
	delay_s(3);
	Add_History(acc_no,"DEPOSIT",amnt);
	CmdLCD(0x01);
    RTC_Read(&sec,&min,&hour,&day,&month,&year);
	sprintf(log,"[%02u-%02u-%04u/%02u:%02u:%02u] ACC:%u DEPOSIT: Rs.%u BALANCE: Rs.%u\r\n",day,month,year,hour,min,sec,acc_no,amnt,Bal);
	U0_TxStr(log);
}